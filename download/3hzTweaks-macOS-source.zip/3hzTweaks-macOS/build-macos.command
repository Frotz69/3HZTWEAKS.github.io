#!/bin/bash
# 3hz Tweaks for macOS - double-click to build and open the app.
#
# Apple builds only happen on macOS, so this is the closest thing to an
# installer: it compiles the app in this folder (about a minute on an M-series
# Mac) and opens it. Everything it needs - ImGui, GLFW, the fonts - is either
# here or downloaded by CMake on the first run.
#
# Needs the Xcode command line tools (free) and CMake.
set -u
cd "$(dirname "$0")" || exit 1

pause() {
    echo
    read -r -n 1 -s -p "Press any key to close this window."
    echo
}

echo "3hz Tweaks for macOS"
echo "--------------------"

if ! xcode-select -p >/dev/null 2>&1; then
    echo "The Xcode command line tools are missing."
    echo
    echo "Run this once, then double-click this file again:"
    echo "    xcode-select --install"
    pause
    exit 1
fi

CMAKE=$(command -v cmake || true)
if [ -z "$CMAKE" ]; then
    for candidate in /opt/homebrew/bin/cmake /usr/local/bin/cmake; do
        if [ -x "$candidate" ]; then
            CMAKE="$candidate"
            break
        fi
    done
fi

if [ -z "$CMAKE" ] && command -v brew >/dev/null 2>&1; then
    echo "CMake is not installed. Installing it with Homebrew (it may ask for your password)."
    brew install cmake || { echo "brew install cmake failed."; pause; exit 1; }
    CMAKE=$(command -v cmake || true)
fi

if [ -z "$CMAKE" ]; then
    echo "CMake is missing."
    echo "Install it with 'brew install cmake', or from https://cmake.org/download/ and run this again."
    pause
    exit 1
fi

echo "Using $CMAKE"
echo "Configuring - the first run downloads GLFW, so give it a minute..."
if ! "$CMAKE" -B build -DCMAKE_BUILD_TYPE=Release; then
    echo
    echo "Configure failed. The output above says why."
    pause
    exit 1
fi

echo "Building..."
if ! "$CMAKE" --build build -j "$(sysctl -n hw.ncpu 2>/dev/null || echo 4)"; then
    echo
    echo "Build failed. The output above says why."
    pause
    exit 1
fi

APP="build/3hz Tweaks.app"
if [ -d "$APP" ]; then
    echo
    echo "Built. Opening $APP"
    open "$APP"
    echo
    echo "The app is unsigned, so macOS may ask you to confirm the first launch"
    echo "(right-click the app and choose Open, or allow it in System Settings > Privacy & Security)."
else
    echo
    echo "The build finished but $APP is not there - check the output above."
fi
pause
