# 3hz Tweaks for macOS

A macOS build of 3hz Tweaks. Same window, same idea — but the work is done with
the Mac's own tools instead of the registry.

The Windows app in `../native` reads and writes the registry, drives services,
WMI and netsh. None of that exists on macOS, so this is not a recompile of that
backend: it is the same shape with a new backend behind it.

![Dashboard](docs/dashboard.png)

*The screenshots in `docs/` are real renders of this interface, taken on Windows
while checking layout — that is why the chip and the disk figures are blank. On a
Mac those cards show the actual hardware.*

## Build

Needs macOS 12 or newer and the Xcode command line tools.

The download from the site is this folder zipped, with a double-click builder
inside:

```sh
unzip 3hzTweaks-macOS-source.zip
open 3hzTweaks-macOS          # then double-click build-macos.command
```

`build-macos.command` checks for the Xcode command line tools and CMake (offering
to install CMake with Homebrew if it is missing), builds, and opens the app. The
build is unsigned, so the first launch needs right-click → Open, or an allow in
System Settings → Privacy & Security.

By hand, it is the usual three commands:

```sh
brew install cmake            # if you do not already have it
cd macos-port
cmake -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j
open "build/3hz Tweaks.app"
```

CMake fetches GLFW 3.4 on the first configure. To use an installed GLFW instead:

```sh
cmake -B build -DTHZ_USE_SYSTEM_GLFW=ON   # requires `brew install glfw`
```

Dear ImGui comes from `../native/thirdparty/imgui`, so both builds stay on one
version. Fonts (Inter + Font Awesome) ship inside the bundle in
`Contents/Resources/assets`.

## What it does

### Tweaks

Every row is one preference, written with `defaults write`, then whatever caches
it is restarted so the change shows immediately. Switching a row back writes the
previous value, so nothing here is one-way.

| Group | Tweak | Preference |
| --- | --- | --- |
| Dock | Hide the Dock | `com.apple.dock autohide` |
| Dock | Scale minimise effect | `com.apple.dock mineffect` |
| Dock | Hide recent applications | `com.apple.dock show-recents` |
| Dock | No hide delay | `com.apple.dock autohide-delay` |
| Dock | Only running apps | `com.apple.dock static-only` |
| Finder | Show all file extensions | `-g AppleShowAllExtensions` |
| Finder | Path bar | `com.apple.finder ShowPathbar` |
| Finder | Status bar | `com.apple.finder ShowStatusBar` |
| Finder | Full path in the title | `com.apple.finder _FXShowPosixPathInTitle` |
| Finder | Folders on top | `com.apple.finder _FXSortFoldersFirst` |
| Finder | Quit Finder | `com.apple.finder QuitMenuItem` |
| Finder | No empty-bin warning | `com.apple.finder WarnOnEmptyTrash` |
| Keyboard | Fast key repeat | `-g KeyRepeat` |
| Keyboard | Short repeat delay | `-g InitialKeyRepeat` |
| Keyboard | Hold to repeat letters | `-g ApplePressAndHoldEnabled` |
| Interface | Less motion | `-g NSAutomaticWindowAnimationsEnabled` |
| Interface | Reduce transparency | `com.apple.universalaccess reduceTransparency` |
| Interface | Dark mode | `-g AppleInterfaceStyle` |
| Interface | Opaque menu bar | `-g AppleEnableMenuBarTransparency` |
| Screenshots | No window shadows | `com.apple.screencapture disable-shadow` |

A tweak counts as on when `defaults read` prints the expected value, so the app
reflects reality on launch rather than remembering what it did last time.

### Tools

One-shot commands, run on a worker thread so the window keeps drawing.

| Tool | What it does | Admin |
| --- | --- | --- |
| Flush DNS | `dscacheutil -flushcache`, restart `mDNSResponder` | yes |
| Test routes | `ping` Cloudflare, Google, Apple; reports average latency | no |
| Wi-Fi status | Network, address and router on the Wi-Fi device | no |
| Renew DHCP lease | `ipconfig set <dev> DHCP` | yes |
| Free inactive memory | `purge` | yes |
| Memory speed | Chip, core count and memory as macOS reports it | no |
| Restart Dock / Finder | `killall Dock` / `killall Finder` | no |
| Drive health | `diskutil info /` — volume, filesystem, SMART | no |
| Battery health | `pmset -g batt` + cycle count and condition | no |
| Hardware report | `system_profiler SPHardwareDataType` | no |
| Rebuild Spotlight index | `mdutil -E /` | yes |
| Empty the bin | Every user trash folder, including other volumes | no |
| List macOS updates | `softwareupdate -l` | no |

"Admin" means the command runs through AppleScript's `do shell script … with
administrator privileges`, so macOS shows its own authorisation dialog. The app
never runs as root itself and never stores a password.

### Disk cleaner

Measures the usual space hogs with `du` and deletes what you tick:

- user caches (`~/Library/Caches`)
- logs (`~/Library/Logs`)
- trash (`~/.Trash` and per-volume `.Trashes`)
- temporary items in `$TMPDIR`, **only files older than a day**
- Xcode derived data
- npm, Yarn, Gradle and Go build caches

Caches, logs and derived data come back on their own. Trash is gone for good, so
the app says so before you press the button.

![Cleaner](docs/cleaner.png)

## Layout

```
macos-port/
  CMakeLists.txt          GLFW + ImGui + the app, built as a .app bundle
  Info.plist.in           bundle metadata (retina, min macOS 12)
  build-macos.command     double-click builder (checks the tools, builds, opens)
  assets/                 Inter.ttf, fa-solid-900.ttf
  src/main.cpp            GLFW/OpenGL context, fonts, theme, frame loop
  src/ui_mac.cpp          sidebar, dashboard, tweaks, tools, cleaner, about
  src/ui_mac.h
  src/mac_backend.cpp     defaults/pmset/sysctl/du/diskutil + the catalogues
  src/mac_backend.h
  src/icons.h             Font Awesome codepoints (same table as Windows)
  docs/                   layout previews
```

## Notes and limits

- This folder is new and self-contained: nothing in `../native` was changed, and
  the Windows build is untouched.
- The port was written on Windows, so it has **not been compiled or run on a
  Mac yet**. The UI was verified headlessly (all five pages, ImGui assertions
  enabled, draw lists software-rasterised into `docs/`), and the shell commands
  were checked against their macOS syntax, but the first `cmake --build` on a
  Mac is the real test.
- The Windows build's accounts, profiles and AI pages are not in this port yet —
  this is the tweaks/tools/cleaner surface first.
- `killall SystemUIServer` is a no-op on macOS 13+ for some menu-bar settings,
  where ControlCenter owns them. The preference is still written; the change may
  need a logout to show.
