#include "mac_backend.h"

#include <algorithm>
#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <fstream>
#include <sstream>
#include <sys/wait.h>
#include <unistd.h>

namespace mac {

// ---------------------------------------------------------------------------
// small helpers
// ---------------------------------------------------------------------------
static std::string Trim(const std::string& s) {
    const size_t a = s.find_first_not_of(" \t\r\n");
    if (a == std::string::npos) return "";
    const size_t b = s.find_last_not_of(" \t\r\n");
    return s.substr(a, b - a + 1);
}

// Wraps a string in single quotes for /bin/sh, including embedded quotes.
static std::string ShQuote(const std::string& s) {
    std::string o = "'";
    for (char c : s) {
        if (c == '\'') o += "'\\''";
        else o += c;
    }
    o += "'";
    return o;
}

static bool Has(const std::string& hay, const char* needle) {
    return hay.find(needle) != std::string::npos;
}

std::string HomeDir() {
    static std::string h;
    if (h.empty()) {
        const char* p = getenv("HOME");
        h = p ? p : "/Users";
    }
    return h;
}

std::string AppSupportDir() { return HomeDir() + "/Library/Application Support/3hz Tweaks"; }
std::string ConfigPath()    { return AppSupportDir() + "/config.conf"; }

bool Run(const std::string& cmd, std::string* out) {
    FILE* p = popen(cmd.c_str(), "r");
    if (!p) return false;
    std::string buf;
    char tmp[4096];
    size_t n = 0;
    while ((n = fread(tmp, 1, sizeof(tmp), p)) > 0) buf.append(tmp, n);
    const int rc = pclose(p);
    if (out) *out = buf;
    return WIFEXITED(rc) && WEXITSTATUS(rc) == 0;
}

bool RunAdmin(const std::string& cmd, std::string* out) {
    // The command has to survive two layers: AppleScript string quoting and the
    // shell that launches osascript. Backslashes and quotes are escaped for the
    // first, the whole -e argument is single-quoted for the second.
    std::string esc;
    for (char c : cmd) {
        if (c == '\\' || c == '"') esc += '\\';
        esc += c;
    }
    const std::string script =
        "do shell script \"" + esc + "\" with administrator privileges";
    return Run("/usr/bin/osascript -e " + ShQuote(script), out);
}

// ---------------------------------------------------------------------------
// config: one key=value per line, values are kept verbatim
// ---------------------------------------------------------------------------
std::map<std::string, std::string> LoadConfig() {
    std::map<std::string, std::string> cfg;
    std::ifstream in(ConfigPath());
    std::string line;
    while (std::getline(in, line)) {
        if (line.empty() || line[0] == '#') continue;
        const size_t eq = line.find('=');
        if (eq == std::string::npos) continue;
        cfg[line.substr(0, eq)] = line.substr(eq + 1);
    }
    return cfg;
}

void SaveConfig(const std::map<std::string, std::string>& cfg) {
    Run("mkdir -p " + ShQuote(AppSupportDir()));
    std::ofstream out(ConfigPath(), std::ios::trunc);
    if (!out) return;
    for (const auto& kv : cfg) out << kv.first << "=" << kv.second << "\n";
}

// ---------------------------------------------------------------------------
// system facts
// ---------------------------------------------------------------------------
static int TakeInt(const std::string& s) {
    return (int)strtol(Trim(s).c_str(), nullptr, 10);
}

static std::string RunOut(const char* cmd) {
    std::string out;
    Run(cmd, &out);
    return Trim(out);
}

static void ReadMemory(mac::SysInfo& info) {
    const unsigned long long bytes = (unsigned long long)strtoull(RunOut("sysctl -n hw.memsize").c_str(), nullptr, 10);
    info.memTotalGb = (int)((bytes + (1ull << 29)) / (1ull << 30));

    // vm_stat is the cheap read: page size on the first line, then counters.
    const std::string vm = RunOut("vm_stat");
    if (!vm.empty() && bytes) {
        unsigned long long page = 4096;
        const size_t psz = vm.find("page size of");
        if (psz != std::string::npos) page = (unsigned long long)strtoull(vm.c_str() + psz + 12, nullptr, 10);
        auto pages = [&](const char* label) -> unsigned long long {
            const size_t at = vm.find(label);
            if (at == std::string::npos) return 0;
            const size_t colon = vm.find(':', at);
            if (colon == std::string::npos) return 0;
            return strtoull(vm.c_str() + colon + 1, nullptr, 10);
        };
        const unsigned long long freePages = pages("Pages free") + pages("Pages speculative");
        const unsigned long long used = bytes - std::min(bytes, freePages * page);
        info.memUsed = (double)used / (double)bytes;
    }
}

static void ReadDisk(mac::SysInfo& info) {
    std::string df;
    if (!Run("df -k /", &df)) return;
    // header line, then the row for the root volume
    std::istringstream ss(df);
    std::string line, last;
    while (std::getline(ss, line))
        if (!Trim(line).empty()) last = line;
    std::istringstream row(last);
    std::string fs, blocks, used, avail;
    row >> fs >> blocks >> used >> avail;
    const unsigned long long total = (unsigned long long)strtoull(blocks.c_str(), nullptr, 10) * 1024ull;
    const unsigned long long u = (unsigned long long)strtoull(used.c_str(), nullptr, 10) * 1024ull;
    if (total) {
        info.diskUsed = (double)u / (double)total;
        info.diskTotalGb = total / (1ull << 30);
        info.diskFreeGb = (unsigned long long)strtoull(avail.c_str(), nullptr, 10) / 1048576ull;
    }
}

static void ReadBattery(mac::SysInfo& info) {
    std::string out;
    if (!Run("pmset -g batt", &out)) return;
    const size_t pct = out.find('%');
    if (pct == std::string::npos) return;
    size_t start = pct;
    while (start > 0 && isdigit((unsigned char)out[start - 1])) start--;
    info.battery = atoi(out.c_str() + start);
    info.charging = Has(out, "charging") || Has(out, "AC Power") || Has(out, "charged");
}

SysInfo ProbeSystem(bool force) {
    static SysInfo cached;
    static time_t at = 0;
    const time_t now = time(nullptr);
    if (!force && at && now - at < 3) return cached;
    at = now;

    SysInfo n;
    n.chip = RunOut("sysctl -n machdep.cpu.brand_string");
    if (n.chip.empty()) n.chip = RunOut("uname -m");
    n.model = RunOut("sysctl -n hw.model");

    const std::string osName = RunOut("sw_vers -productName");
    const std::string osVer = RunOut("sw_vers -productVersion");
    n.os = osName.empty() ? ("macOS " + osVer) : (osName + " " + osVer);

    n.cores = TakeInt(RunOut("sysctl -n hw.ncpu"));
    ReadMemory(n);
    ReadDisk(n);
    ReadBattery(n);

    cached = n;
    return cached;
}

// ---------------------------------------------------------------------------
// tweaks
//
// Each entry is one `defaults` key. onCmd/offCmd are the two writes; readCmd
// prints what is stored and onValue is the output that means "on". `restart`
// is the app that has to be relaunched for the change to be visible.
// ---------------------------------------------------------------------------
static void AddTweak(std::vector<Tweak>& v, const char* key, const char* cat,
                     const char* title, const char* desc,
                     const char* domain, const char* pref,
                     const char* onCmd, const char* offCmd, const char* onValue,
                     const char* restart) {
    Tweak t;
    t.key = key; t.cat = cat; t.title = title; t.desc = desc;
    t.readCmd = std::string("defaults read ") + domain + " " + pref;
    t.onCmd = onCmd; t.offCmd = offCmd; t.onValue = onValue; t.restart = restart;
    v.push_back(t);
}

const std::vector<Tweak>& TweakCatalog() {
    static std::vector<Tweak> v;
    if (!v.empty()) return v;

    // ---- Dock
    AddTweak(v, "dock.autohide", "Dock", "Hide the Dock",
             "The Dock slides away until the pointer reaches that edge.",
             "com.apple.dock", "autohide",
             "defaults write com.apple.dock autohide -bool true",
             "defaults write com.apple.dock autohide -bool false", "1", "killall Dock");
    AddTweak(v, "dock.scale", "Dock", "Scale minimise effect",
             "Windows shrink into the Dock instead of the genie squashing them.",
             "com.apple.dock", "mineffect",
             "defaults write com.apple.dock mineffect -string scale",
             "defaults write com.apple.dock mineffect -string genie", "scale", "killall Dock");
    AddTweak(v, "dock.norecents", "Dock", "Hide recent applications",
             "Keeps the right-hand end of the Dock for folders and the bin.",
             "com.apple.dock", "show-recents",
             "defaults write com.apple.dock show-recents -bool false",
             "defaults write com.apple.dock show-recents -bool true", "0", "killall Dock");
    AddTweak(v, "dock.nodelay", "Dock", "No hide delay",
             "The Dock appears the instant the pointer touches the edge.",
             "com.apple.dock", "autohide-delay",
             "defaults write com.apple.dock autohide-delay -float 0",
             "defaults delete com.apple.dock autohide-delay", "0", "killall Dock");
    AddTweak(v, "dock.running", "Dock", "Only running apps",
             "Removes pinned icons; the Dock shows what is open right now.",
             "com.apple.dock", "static-only",
             "defaults write com.apple.dock static-only -bool true",
             "defaults write com.apple.dock static-only -bool false", "1", "killall Dock");

    // ---- Finder
    AddTweak(v, "finder.extensions", "Finder", "Show all file extensions",
             "Every file shows its extension, not just the odd ones.",
             "-g", "AppleShowAllExtensions",
             "defaults write -g AppleShowAllExtensions -bool true",
             "defaults write -g AppleShowAllExtensions -bool false", "1", "killall Finder");
    AddTweak(v, "finder.pathbar", "Finder", "Path bar",
             "A breadcrumb of the folder you are in at the bottom of the window.",
             "com.apple.finder", "ShowPathbar",
             "defaults write com.apple.finder ShowPathbar -bool true",
             "defaults write com.apple.finder ShowPathbar -bool false", "1", "killall Finder");
    AddTweak(v, "finder.statusbar", "Finder", "Status bar",
             "Item count and free space along the bottom of every window.",
             "com.apple.finder", "ShowStatusBar",
             "defaults write com.apple.finder ShowStatusBar -bool true",
             "defaults write com.apple.finder ShowStatusBar -bool false", "1", "killall Finder");
    AddTweak(v, "finder.posix", "Finder", "Full path in the title",
             "The window title shows the real path instead of the folder name.",
             "com.apple.finder", "_FXShowPosixPathInTitle",
             "defaults write com.apple.finder _FXShowPosixPathInTitle -bool true",
             "defaults write com.apple.finder _FXShowPosixPathInTitle -bool false", "1", "killall Finder");
    AddTweak(v, "finder.foldersfirst", "Finder", "Folders on top",
             "Folders sort ahead of files, however the list is sorted.",
             "com.apple.finder", "_FXSortFoldersFirst",
             "defaults write com.apple.finder _FXSortFoldersFirst -bool true",
             "defaults write com.apple.finder _FXSortFoldersFirst -bool false", "1", "killall Finder");
    AddTweak(v, "finder.quit", "Finder", "Quit Finder",
             "Adds Quit to Finder's menu, so it can be closed like an app.",
             "com.apple.finder", "QuitMenuItem",
             "defaults write com.apple.finder QuitMenuItem -bool true",
             "defaults write com.apple.finder QuitMenuItem -bool false", "1", "killall Finder");
    AddTweak(v, "finder.trashwarn", "Finder", "No empty-bin warning",
             "Emptying the bin stops asking for confirmation.",
             "com.apple.finder", "WarnOnEmptyTrash",
             "defaults write com.apple.finder WarnOnEmptyTrash -bool false",
             "defaults write com.apple.finder WarnOnEmptyTrash -bool true", "0", "killall Finder");

    // ---- Keyboard
    AddTweak(v, "key.repeat", "Keyboard", "Fast key repeat",
             "Holding a key repeats it at about 30 times a second.",
             "-g", "KeyRepeat",
             "defaults write -g KeyRepeat -int 2",
             "defaults write -g KeyRepeat -int 6", "2", "");
    AddTweak(v, "key.initial", "Keyboard", "Short repeat delay",
             "The pause before a held key starts repeating, cut to 15.",
             "-g", "InitialKeyRepeat",
             "defaults write -g InitialKeyRepeat -int 15",
             "defaults write -g InitialKeyRepeat -int 25", "15", "");
    AddTweak(v, "key.hold", "Keyboard", "Hold to repeat letters",
             "A held key repeats instead of offering accent choices.",
             "-g", "ApplePressAndHoldEnabled",
             "defaults write -g ApplePressAndHoldEnabled -bool false",
             "defaults write -g ApplePressAndHoldEnabled -bool true", "0", "");

    // ---- Interface
    AddTweak(v, "ui.motion", "Interface", "Less motion",
             "Turns off the automatic window and sheet animations.",
             "-g", "NSAutomaticWindowAnimationsEnabled",
             "defaults write -g NSAutomaticWindowAnimationsEnabled -bool false",
             "defaults write -g NSAutomaticWindowAnimationsEnabled -bool true", "0", "");
    AddTweak(v, "ui.transparency", "Interface", "Reduce transparency",
             "Sidebars and menus draw opaque, which is cheaper to composite.",
             "com.apple.universalaccess", "reduceTransparency",
             "defaults write com.apple.universalaccess reduceTransparency -bool true",
             "defaults write com.apple.universalaccess reduceTransparency -bool false", "1", "killall SystemUIServer");
    AddTweak(v, "ui.dark", "Interface", "Dark mode",
             "The system-wide appearance, set from here instead of System Settings.",
             "-g", "AppleInterfaceStyle",
             "defaults write -g AppleInterfaceStyle -string Dark",
             "defaults delete -g AppleInterfaceStyle", "Dark", "killall Dock");
    AddTweak(v, "ui.menubar", "Interface", "Opaque menu bar",
             "Stops the menu bar tinting itself with the wallpaper.",
             "-g", "AppleEnableMenuBarTransparency",
             "defaults write -g AppleEnableMenuBarTransparency -bool false",
             "defaults write -g AppleEnableMenuBarTransparency -bool true", "0", "killall SystemUIServer");

    // ---- Screenshots
    AddTweak(v, "shot.shadow", "Screenshots", "No window shadows",
             "Window captures come out without the drop shadow around them.",
             "com.apple.screencapture", "disable-shadow",
             "defaults write com.apple.screencapture disable-shadow -bool true",
             "defaults write com.apple.screencapture disable-shadow -bool false", "1", "killall SystemUIServer");

    return v;
}

bool ReadTweak(const Tweak& t) {
    std::string out;
    if (!Run(t.readCmd, &out)) return false;   // unset key: the tweak is off
    return Trim(out) == t.onValue;
}

bool ApplyTweak(const Tweak& t, bool on) {
    std::string out;
    const bool ok = Run(on ? t.onCmd : t.offCmd, &out);
    if (!ok) return false;
    if (!t.restart.empty()) Run(t.restart, nullptr);
    return true;
}

// ---------------------------------------------------------------------------
// tools
// ---------------------------------------------------------------------------
const std::vector<Tool>& ToolCatalog() {
    static std::vector<Tool> v;
    if (!v.empty()) return v;
    auto add = [&](const char* key, const char* cat, const char* title, const char* desc, bool admin) {
        Tool t;
        t.key = key; t.cat = cat; t.title = title; t.desc = desc; t.admin = admin;
        v.push_back(t);
    };
    add("mac.dns", "Network", "Flush DNS",
        "Empties the resolver cache and restarts the DNS responder.", true);
    add("mac.routes", "Network", "Test routes",
        "Pings Cloudflare, Google and Apple and reports the average latency.", false);
    add("mac.wifi", "Network", "Wi-Fi status",
        "The network the Wi-Fi adapter is on, its address and its gateway.", false);
    add("mac.dhcp", "Network", "Renew DHCP lease",
        "Asks the router for a fresh address on the main interface.", true);

    add("mac.purge", "Memory", "Free inactive memory",
        "Drops the file cache and inactive pages so the next launch starts clean.", true);
    add("mac.xmpnotice", "Memory", "Memory speed",
        "Total memory, chip and the speed macOS reports for the modules.", false);

    add("mac.dock", "Maintenance", "Restart Dock",
        "Reloads the Dock - handy straight after a Dock tweak.", false);
    add("mac.finder", "Maintenance", "Restart Finder",
        "Reloads Finder and its menu bar extras.", false);
    add("mac.disk", "Maintenance", "Drive health",
        "Volume, filesystem and SMART status for the boot disk.", false);
    add("mac.battery", "Maintenance", "Battery health",
        "Charge, cycle count and condition, straight from the power hardware.", false);
    add("mac.hw", "Maintenance", "Hardware report",
        "Model, chip and core count as macOS reports them.", false);

    add("mac.spotlight", "Cleanup", "Rebuild Spotlight index",
        "Erases the search index so Spotlight rebuilds it from scratch.", true);
    add("mac.trash", "Cleanup", "Empty the bin",
        "Empties every user trash folder, including ones on other volumes.", false);
    add("mac.updates", "Cleanup", "List macOS updates",
        "Asks Apple which updates this Mac has waiting.", false);

    return v;
}

static int ParsePingAvg(const std::string& out) {
    // round-trip min/avg/max/stddev = 12.3/13.4/14.5/1.2 ms
    const size_t eq = out.find("= ");
    if (eq == std::string::npos) return -1;
    const size_t slash = out.find('/', eq + 2);
    if (slash == std::string::npos) return -1;
    return (int)(atof(out.substr(eq + 2, slash - eq - 2).c_str()) + 0.5);
}

static std::string WifiDevice() {
    // networksetup -listallhardwareports prints a block per port; the Wi-Fi one
    // is the block whose Hardware Port line mentions Wi-Fi or AirPort.
    std::string out;
    Run("networksetup -listallhardwareports", &out);
    std::istringstream ss(out);
    std::string line, pending;
    bool wifiPort = false;
    while (std::getline(ss, line)) {
        if (Has(line, "Hardware Port:")) wifiPort = Has(line, "Wi-Fi") || Has(line, "AirPort");
        else if (wifiPort && Has(line, "Device:")) return Trim(line.substr(line.find(':') + 1));
    }
    return "en0";
}

ToolOut RunTool(const std::string& key) {
    ToolOut r;
    std::string out;

    if (key == "mac.dns") {
        r.ok = RunAdmin("dscacheutil -flushcache && killall -HUP mDNSResponder", nullptr);
        r.text = r.ok ? "DNS cache flushed and the responder restarted"
                      : "Could not flush the DNS cache";
        return r;
    }
    if (key == "mac.routes") {
        struct Host { const char* host; const char* label; };
        const Host hosts[] = {{"1.1.1.1", "Cloudflare"}, {"8.8.8.8", "Google"}, {"apple.com", "Apple"}};
        std::string text;
        int answered = 0, worst = 0;
        for (const Host& h : hosts) {
            // -t caps the wait per reply, so an offline Mac answers quickly.
            const std::string cmd = std::string("ping -c 3 -t 5 -q ") + h.host;
            std::string ping;
            if (!Run(cmd, &ping) && ping.empty()) continue;
            const int avg = ParsePingAvg(ping);
            if (avg < 0) continue;
            answered++;
            worst = std::max(worst, avg);
            if (!text.empty()) text += "\n";
            text += std::string(h.label) + "  " + std::to_string(avg) + " ms";
        }
        r.ok = answered > 0;
        r.text = answered ? text + "\nWorst average: " + std::to_string(worst) + " ms"
                          : "No host answered - is this Mac online?";
        return r;
    }
    if (key == "mac.wifi") {
        const std::string dev = WifiDevice();
        const std::string net = RunOut(("networksetup -getairportnetwork " + dev).c_str());
        const std::string ip = RunOut(("ipconfig getifaddr " + dev).c_str());
        const std::string router = RunOut("route -n get default | awk '/gateway/ {print $2}'");
        if (net.empty() && ip.empty()) {
            r.text = "Wi-Fi looks off on " + dev;
            return r;
        }
        std::string name = net;
        const size_t colon = name.find(": ");
        if (colon != std::string::npos && Has(name, "Current Wi-Fi Network")) name = name.substr(colon + 2);
        if (name.empty()) name = "not on a network";
        r.ok = true;
        r.text = name + "  (" + dev + ")" +
                 (ip.empty() ? "" : ("\nAddress " + ip)) +
                 (router.empty() ? "" : ("\nRouter " + router));
        return r;
    }
    if (key == "mac.dhcp") {
        const std::string dev = WifiDevice();
        r.ok = RunAdmin("ipconfig set " + dev + " DHCP", nullptr);
        r.text = r.ok ? ("Asked " + dev + " for a fresh DHCP lease") : "Could not renew the lease";
        return r;
    }
    if (key == "mac.purge") {
        r.ok = RunAdmin("purge", nullptr);
        r.text = r.ok ? "Inactive memory released" : "purge needs administrator rights";
        return r;
    }
    if (key == "mac.xmpnotice") {
        const SysInfo s = ProbeSystem(true);
        r.ok = true;
        r.text = s.chip + "  " + std::to_string(s.memTotalGb) + " GB unified memory" +
                 (s.cores ? ("\n" + std::to_string(s.cores) + " cores") : "");
        return r;
    }
    if (key == "mac.dock") {
        r.ok = Run("killall Dock", nullptr);
        r.text = r.ok ? "Dock restarted" : "The Dock was not running";
        return r;
    }
    if (key == "mac.finder") {
        r.ok = Run("killall Finder", nullptr);
        r.text = r.ok ? "Finder restarted" : "Finder was not running";
        return r;
    }
    if (key == "mac.disk") {
        std::string info;
        Run("diskutil info / | grep -E 'Volume Name|File System Personality|Disk Size|SMART Status|Container Total Space'", &info);
        info = Trim(info);
        r.ok = !info.empty();
        r.text = r.ok ? info : "Could not read the boot volume";
        return r;
    }
    if (key == "mac.battery") {
        std::string batt, power;
        Run("pmset -g batt", &batt);
        Run("system_profiler SPPowerDataType | grep -E 'Cycle Count|Condition|Maximum Capacity'", &power);
        std::string text = Trim(batt);
        const std::string extra = Trim(power);
        if (!extra.empty()) text += "\n" + extra;
        r.ok = !text.empty();
        r.text = r.ok ? text : "This Mac has no battery";
        return r;
    }
    if (key == "mac.hw") {
        std::string info;
        Run("system_profiler SPHardwareDataType | grep -E 'Model Name|Model Identifier|Chip|Processor Name|Total Number of Cores|Memory'", &info);
        info = Trim(info);
        r.ok = !info.empty();
        r.text = r.ok ? info : "Could not read the hardware profile";
        return r;
    }
    if (key == "mac.spotlight") {
        r.ok = RunAdmin("mdutil -E /", &out);
        r.text = r.ok ? "Spotlight is rebuilding the index - search stays thin for a while"
                      : "Could not rebuild the index";
        return r;
    }
    if (key == "mac.trash") {
        const unsigned long long before = GroupBytesFor("trash");
        Run("find " + ShQuote(HomeDir() + "/.Trash") + " -mindepth 1 -maxdepth 1 -exec rm -rf {} + "
            "2>/dev/null", nullptr);
        Run("for v in /Volumes/*; do [ -d \"$v/.Trashes/$(id -u)\" ] && find \"$v/.Trashes/$(id -u)\" "
            "-mindepth 1 -maxdepth 1 -exec rm -rf {} + 2>/dev/null; done", nullptr);
        const unsigned long long after = GroupBytesFor("trash");
        const unsigned long long freed = before > after ? before - after : 0;
        r.ok = true;
        r.text = freed ? ("Emptied " + SizeText(freed) + " of trash") : "The bin was already empty";
        return r;
    }
    if (key == "mac.updates") {
        std::string list;
        Run("softwareupdate -l 2>&1 | head -12", &list);
        list = Trim(list);
        r.ok = true;
        r.text = list.empty() ? "No updates waiting" : list;
        return r;
    }
    r.text = "Unknown tool: " + key;
    return r;
}

// ---------------------------------------------------------------------------
// cleaner
// ---------------------------------------------------------------------------
struct CleanDef {
    const char* key;
    const char* title;
    const char* desc;
    const char* paths[4];
};

static const CleanDef CLEAN_DEFS[] = {
    {"caches", "User caches",
     "App caches in your Library. Every app rebuilds what it needs as it runs.", {"~/Library/Caches", "", "", ""}},
    {"logs", "Logs",
     "Log files from apps and crashes. New ones appear as soon as something runs.", {"~/Library/Logs", "", "", ""}},
    {"trash", "Trash",
     "Everything you have deleted but not emptied.", {"~/.Trash", "", "", ""}},
    {"tmp", "Temporary items",
     "Stale files in your per-user temp folder, older than a day.", {"TMPDIR", "", "", ""}},
    {"xcode", "Xcode derived data",
     "Build products and indexes. Xcode regenerates them on the next build.", {"~/Library/Developer/Xcode/DerivedData", "", "", ""}},
    {"dev", "Package manager caches",
     "npm, Yarn, Gradle and Go build caches. They refill on the next install.", {"~/.npm/_cacache", "~/.gradle/caches", "~/Library/Caches/go-build", "~/Library/Caches/Yarn"}},
};
static const int CLEANDEFS = (int)(sizeof(CLEAN_DEFS) / sizeof(CLEAN_DEFS[0]));

static std::vector<std::string> CleanPaths(const std::string& key) {
    std::vector<std::string> out;
    for (int i = 0; i < CLEANDEFS; i++) {
        if (key != CLEAN_DEFS[i].key) continue;
        for (const char* p : CLEAN_DEFS[i].paths) {
            if (!p || !*p) continue;
            std::string path(p);
            if (path == "TMPDIR") {
                const char* t = getenv("TMPDIR");
                if (!t) continue;
                path = t;
            } else if (path[0] == '~') {
                path = HomeDir() + path.substr(1);
            }
            out.push_back(path);
        }
    }
    return out;
}

// bytes and files under one path, without touching it
static void MeasurePath(const std::string& path, unsigned long long* bytes, int* files) {
    std::string out;
    if (!Run("du -sk " + ShQuote(path) + " 2>/dev/null", &out)) return;
    std::istringstream row(out);
    unsigned long long kb = 0;
    row >> kb;
    *bytes += kb * 1024ull;

    std::string count;
    if (Run("find " + ShQuote(path) + " -type f 2>/dev/null | wc -l", &count))
        *files += (int)strtol(Trim(count).c_str(), nullptr, 10);
}

unsigned long long GroupBytesFor(const std::string& key) {
    unsigned long long bytes = 0;
    int files = 0;
    for (const std::string& p : CleanPaths(key)) MeasurePath(p, &bytes, &files);
    return bytes;
}

std::vector<CleanGroup> ScanCleaner() {
    std::vector<CleanGroup> out;
    for (int i = 0; i < CLEANDEFS; i++) {
        CleanGroup g;
        g.key = CLEAN_DEFS[i].key;
        g.title = CLEAN_DEFS[i].title;
        g.desc = CLEAN_DEFS[i].desc;
        for (const std::string& p : CleanPaths(g.key)) MeasurePath(p, &g.bytes, &g.files);
        out.push_back(g);
    }
    return out;
}

CleanOut CleanRun(const std::vector<std::string>& keys) {
    CleanOut r;
    const std::vector<CleanGroup> before = ScanCleaner();
    for (const std::string& key : keys) {
        unsigned long long beforeBytes = 0;
        int beforeFiles = 0;
        for (const CleanGroup& g : before)
            if (g.key == key) { beforeBytes = g.bytes; beforeFiles = g.files; }

        for (const std::string& p : CleanPaths(key)) {
            // "tmp" only clears things a day old: the temp folder is shared with
            // whatever is running right now, including this app.
            const std::string age = (key == "tmp") ? " -mtime +1" : "";
            Run("find " + ShQuote(p) + " -mindepth 1 -maxdepth 1" + age + " -exec rm -rf {} + 2>/dev/null",
                nullptr);
        }

        const unsigned long long afterBytes = GroupBytesFor(key);
        int afterFiles = 0;
        for (const CleanGroup& g : ScanCleaner())
            if (g.key == key) afterFiles = g.files;

        if (beforeBytes > afterBytes) {
            r.freed += beforeBytes - afterBytes;
            r.files += std::max(0, beforeFiles - afterFiles);
            r.groups++;
        }
    }
    return r;
}

std::string SizeText(unsigned long long bytes) {
    char b[48];
    if (bytes >= (1ull << 30)) snprintf(b, sizeof(b), "%.1f GB", bytes / 1073741824.0);
    else if (bytes >= (1ull << 20)) snprintf(b, sizeof(b), "%.1f MB", bytes / 1048576.0);
    else snprintf(b, sizeof(b), "%llu KB", bytes / 1024ull);
    return b;
}

} // namespace mac
