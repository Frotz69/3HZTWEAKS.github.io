#include "ui_mac.h"

#include "icons.h"
#include "mac_backend.h"

#include <algorithm>
#include <atomic>
#include <cfloat>
#include <cstdio>
#include <functional>
#include <map>
#include <mutex>
#include <set>
#include <string>
#include <thread>
#include <vector>

// ---------------------------------------------------------------------------
// palette - the same values the Windows build uses, so both apps look related
// ---------------------------------------------------------------------------
static const ImU32 C_BG     = IM_COL32(9, 12, 17, 255);
static const ImU32 C_SIDE   = IM_COL32(11, 15, 21, 255);
static const ImU32 C_CARD   = IM_COL32(15, 22, 32, 255);
static const ImU32 C_CARD2  = IM_COL32(18, 26, 37, 255);
static const ImU32 C_EDGE   = IM_COL32(32, 43, 58, 255);
static const ImU32 C_HI     = IM_COL32(233, 238, 245, 255);
static const ImU32 C_LO     = IM_COL32(133, 145, 160, 255);
static const ImU32 C_DIM    = IM_COL32(96, 107, 121, 255);
static const ImU32 C_ACC    = IM_COL32(91, 168, 240, 255);
static const ImU32 C_ACCDK  = IM_COL32(10, 18, 28, 255);
static const ImU32 C_OK     = IM_COL32(70, 190, 145, 255);
static const ImU32 C_WARN   = IM_COL32(232, 176, 96, 255);
static const ImU32 C_BAROFF = IM_COL32(40, 52, 68, 255);
static const ImU32 C_HOV    = IM_COL32(255, 255, 255, 9);
static const ImU32 C_ACT    = IM_COL32(31, 45, 62, 255);

static ImFont* g_body = nullptr;
static ImFont* g_small = nullptr;
static ImFont* g_icons = nullptr;

static const float kSide = 224.f;
static const float kPad = 30.f;

// ---------------------------------------------------------------------------
// state
// ---------------------------------------------------------------------------
enum Page { Page_Dash, Page_Tweaks, Page_Tools, Page_Cleaner, Page_About };

struct State {
    Page page = Page_Dash;
    std::string cat = "All";
    std::map<std::string, bool> on;     // tweak key -> current value
    std::set<std::string> pick;         // cleaner groups ticked
    std::vector<mac::CleanGroup> groups;
    bool scanned = false;
    std::string toast;
    bool toastOk = true;
    double toastAt = -1e9;
};
static State g;

// One job at a time. Scanning caches, pinging and asking for authorisation all
// block for a while, and the UI has to keep drawing through it.
struct Job {
    std::atomic<bool> running{false};
    std::mutex mu;
    bool pending = false, ok = false;
    std::string text;
    std::string label;
    std::vector<mac::CleanGroup> groups;
    bool groupsReady = false;
};
static Job g_job;

static bool Busy() { return g_job.running.load(); }

static std::string JobLabel() {
    std::lock_guard<std::mutex> l(g_job.mu);
    return g_job.label;
}

static void JobResult(bool ok, const std::string& text) {
    std::lock_guard<std::mutex> l(g_job.mu);
    g_job.pending = true;
    g_job.ok = ok;
    g_job.text = text;
}

static void JobGroups(std::vector<mac::CleanGroup> groups) {
    std::lock_guard<std::mutex> l(g_job.mu);
    g_job.groups = std::move(groups);
    g_job.groupsReady = true;
}

static void StartJob(const std::string& label, std::function<void()> fn) {
    bool idle = false;
    if (!g_job.running.compare_exchange_strong(idle, true)) return;
    {
        std::lock_guard<std::mutex> l(g_job.mu);
        g_job.label = label;
        g_job.pending = false;
        g_job.text.clear();
    }
    std::thread([fn]() {
        fn();
        g_job.running = false;
    }).detach();
}

static void SetToast(const std::string& text, bool ok) {
    if (text.empty()) return;
    g.toast = text;
    g.toastOk = ok;
    g.toastAt = ImGui::GetTime();
}

static void PumpJob() {
    std::lock_guard<std::mutex> l(g_job.mu);
    if (g_job.pending) {
        if (!g_job.text.empty()) SetToast(g_job.text, g_job.ok);
        g_job.pending = false;
        g_job.text.clear();
    }
    if (g_job.groupsReady) {
        g.groups = g_job.groups;
        g.scanned = true;
        g.pick.clear();
        g_job.groupsReady = false;
    }
}

// ---------------------------------------------------------------------------
// drawing helpers
// ---------------------------------------------------------------------------
static float TW(const char* s, float size, ImFont* f = nullptr) {
    ImFont* font = f ? f : g_body;
    return font->CalcTextSizeA(size, FLT_MAX, 0.f, s).x;
}

static float TW(const std::string& s, float size, ImFont* f = nullptr) {
    return TW(s.c_str(), size, f);
}

static void Txt(ImVec2 p, const std::string& s, float size, ImU32 col, ImFont* f = nullptr) {
    if (s.empty()) return;
    ImGui::GetWindowDrawList()->AddText(f ? f : g_body, size, p, col, s.c_str());
}

// Trims text with an ellipsis so a long description can never spill over the
// switch on the right of a row.
static std::string Fit(const std::string& s, float size, float width, ImFont* f = nullptr) {
    if (width <= 8.f || TW(s, size, f) <= width) return s;
    std::string t = s;
    while (!t.empty() && TW(t + "...", size, f) > width) t.pop_back();
    return t + "...";
}

// Draws word-wrapped text from `pos` and returns the height it used.
static float Para(ImVec2 pos, const std::string& text, float size, ImU32 col, float width,
                  float lineH = 1.f) {
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImFont* f = g_body;
    if (lineH <= 0.f) lineH = size * 1.45f;
    float y = pos.y;
    std::string line;
    size_t i = 0;
    while (i <= text.size()) {
        const size_t sp = text.find(' ', i);
        const std::string word = text.substr(i, sp == std::string::npos ? std::string::npos : sp - i);
        const std::string test = line.empty() ? word : line + " " + word;
        if (!line.empty() && TW(test, size, f) > width) {
            dl->AddText(f, size, ImVec2(pos.x, y), col, line.c_str());
            y += lineH;
            line = word;
        } else {
            line = test;
        }
        if (sp == std::string::npos) break;
        i = sp + 1;
    }
    if (!line.empty()) {
        dl->AddText(f, size, ImVec2(pos.x, y), col, line.c_str());
        y += lineH;
    }
    return y - pos.y;
}

static void Switch(ImVec2 center, bool on) {
    ImDrawList* dl = ImGui::GetWindowDrawList();
    const ImVec2 a(center.x - 21.f, center.y - 12.f);
    const ImVec2 b(center.x + 21.f, center.y + 12.f);
    dl->AddRectFilled(a, b, on ? C_ACC : C_BAROFF, 12.f);
    dl->AddCircleFilled(ImVec2(on ? b.x - 12.f : a.x + 12.f, center.y), 9.f,
                        IM_COL32(244, 248, 253, 255), 28);
}

static void Bar(ImVec2 p, float width, float frac, ImU32 col = C_ACC, float h = 6.f) {
    ImDrawList* dl = ImGui::GetWindowDrawList();
    frac = std::max(0.f, std::min(1.f, frac));
    dl->AddRectFilled(p, ImVec2(p.x + width, p.y + h), C_BAROFF, h * 0.5f);
    if (frac > 0.f)
        dl->AddRectFilled(p, ImVec2(p.x + std::max(width * frac, h), p.y + h), col, h * 0.5f);
}

static void Pill(ImVec2 p, const std::string& text, ImU32 fg, ImU32 bg) {
    ImDrawList* dl = ImGui::GetWindowDrawList();
    const float w = TW(text, 11.5f, g_small) + 16.f;
    dl->AddRectFilled(p, ImVec2(p.x + w, p.y + 20.f), bg, 10.f);
    dl->AddText(g_small, 11.5f, ImVec2(p.x + 8.f, p.y + 4.f), fg, text.c_str());
}

static bool Btn(const char* label, ImVec2 size, bool primary = false, bool disabled = false) {
    // A greyed-out primary button should read as unavailable, not as the
    // brightest thing on the page.
    const bool fill = primary && !disabled;
    ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 9.f);
    ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(14.f, 8.f));
    ImGui::PushStyleColor(ImGuiCol_Button, fill ? C_ACC : IM_COL32(27, 36, 48, 255));
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, fill ? IM_COL32(118, 188, 252, 255) : IM_COL32(37, 49, 65, 255));
    ImGui::PushStyleColor(ImGuiCol_ButtonActive, fill ? IM_COL32(72, 146, 214, 255) : IM_COL32(45, 59, 78, 255));
    ImGui::PushStyleColor(ImGuiCol_Text, fill ? C_ACCDK : (disabled ? C_DIM : C_HI));
    ImGui::PushStyleColor(ImGuiCol_TextDisabled, C_DIM);
    if (disabled) ImGui::BeginDisabled();
    const bool hit = ImGui::Button(label, size);
    if (disabled) ImGui::EndDisabled();
    ImGui::PopStyleColor(5);
    ImGui::PopStyleVar(2);
    return hit && !disabled;
}

static bool Chip(const char* label, bool active, float* x, float y) {
    const float w = TW(label, 13.f, g_small) + 24.f;
    const ImVec2 p(*x, y);
    ImGui::SetCursorScreenPos(p);
    ImGui::InvisibleButton(label, ImVec2(w, 30.f));
    const bool hov = ImGui::IsItemHovered();
    ImDrawList* dl = ImGui::GetWindowDrawList();
    const ImU32 bg = active ? IM_COL32(34, 55, 80, 255) : (hov ? C_HOV : 0);
    if (bg) dl->AddRectFilled(p, ImVec2(p.x + w, p.y + 30.f), bg, 9.f);
    dl->AddText(g_small, 13.f, ImVec2(p.x + 12.f, p.y + 7.f),
                active ? C_HI : C_LO, label);
    *x += w + 8.f;
    return ImGui::IsItemClicked();
}

// A card is a child window with the card background. It reserves its whole area
// up front with one dummy item: cards lay their contents out at absolute offsets,
// and ImGui asserts when the cursor is pushed past the space already claimed.
static void CardBegin(const char* id, float width, float height) {
    ImGui::PushStyleColor(ImGuiCol_ChildBg, ImGui::ColorConvertU32ToFloat4(C_CARD));
    ImGui::PushStyleColor(ImGuiCol_Border, ImGui::ColorConvertU32ToFloat4(C_EDGE));
    ImGui::PushStyleVar(ImGuiStyleVar_ChildRounding, 14.f);
    ImGui::PushStyleVar(ImGuiStyleVar_ChildBorderSize, 1.f);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(18.f, 16.f));
    ImGui::BeginChild(id, ImVec2(width, height), ImGuiChildFlags_Borders,
                      ImGuiWindowFlags_NoMove);
    const ImVec2 start = ImGui::GetCursorScreenPos();
    // Leave out one item spacing, otherwise the reservation alone pushes the
    // content past the card and every card grows a scrollbar.
    const float reserve =
        ImGui::GetContentRegionAvail().y - ImGui::GetStyle().ItemSpacing.y - 2.f;
    ImGui::Dummy(ImVec2(1.f, std::max(0.f, reserve)));
    ImGui::SetCursorScreenPos(start);
}

static void CardEnd() {
    // Cards end on drawn text more often than on a widget, and ImGui needs one
    // last item to accept a cursor that was placed by hand.
    ImGui::Dummy(ImVec2(1.f, 1.f));
    ImGui::EndChild();
    ImGui::PopStyleVar(3);
    ImGui::PopStyleColor(2);
}

static void PageHeader(const char* title, const char* sub) {
    const ImVec2 p = ImGui::GetCursorScreenPos();
    Txt(p, title, 26.f, C_HI);
    float h = 38.f;
    if (sub && *sub) {
        Txt(ImVec2(p.x, p.y + h), Fit(sub, 13.5f, ImGui::GetContentRegionAvail().x - 4.f), 13.5f,
            C_LO);
        h += 26.f;
    }
    ImGui::Dummy(ImVec2(1.f, h));
}

static void Spacer(float h) {
    ImGui::Dummy(ImVec2(1.f, h));
}

static void Sidebar(ImVec2 origin, ImVec2 size) {
    ImDrawList* dl = ImGui::GetWindowDrawList();
    dl->AddRectFilled(origin, ImVec2(origin.x + kSide, origin.y + size.y), C_SIDE);
    dl->AddLine(ImVec2(origin.x + kSide, origin.y), ImVec2(origin.x + kSide, origin.y + size.y),
                C_EDGE);

    // logo
    ImVec2 lp(origin.x + 20.f, origin.y + 22.f);
    dl->AddRectFilled(lp, ImVec2(lp.x + 26.f, lp.y + 26.f), IM_COL32(30, 48, 70, 255), 8.f);
    Txt(ImVec2(lp.x + 6.f, lp.y + 3.f), ICON_BOLT, 15.f, C_ACC, g_icons);
    Txt(ImVec2(lp.x + 36.f, lp.y + 4.f), "3hz Tweaks", 16.5f, C_HI);

    struct Nav { Page page; const char* icon; const char* label; };
    static const Nav items[] = {
        {Page_Dash, ICON_HOUSE, "Dashboard"},
        {Page_Tweaks, ICON_BOLT, "Tweaks"},
        {Page_Tools, ICON_TOOLBOX, "Tools"},
        {Page_Cleaner, ICON_TRASH, "Cleaner"},
        {Page_About, ICON_HELP, "About"},
    };
    float y = origin.y + 78.f;
    for (int i = 0; i < 5; i++) {
        const ImVec2 a(origin.x + 12.f, y);
        const ImVec2 b(origin.x + kSide - 12.f, y + 40.f);
        ImGui::SetCursorScreenPos(a);
        ImGui::PushID(i);
        ImGui::InvisibleButton("nav", ImVec2(b.x - a.x, 40.f));
        const bool active = g.page == items[i].page;
        const bool hov = ImGui::IsItemHovered();
        if (!active && hov) dl->AddRectFilled(a, b, C_HOV, 9.f);
        if (active) {
            dl->AddRectFilled(a, b, C_ACT, 9.f);
            dl->AddRectFilled(ImVec2(a.x - 1.f, a.y + 11.f), ImVec2(a.x + 2.f, b.y - 11.f),
                              C_ACC, 2.f);
        }
        Txt(ImVec2(a.x + 17.f, a.y + 9.f), items[i].icon, 16.f,
            active ? C_ACC : C_LO, g_icons);
        Txt(ImVec2(a.x + 46.f, a.y + 10.f), items[i].label, 14.5f,
            active ? C_HI : (hov ? C_HI : C_LO));
        if (ImGui::IsItemClicked()) g.page = items[i].page;
        ImGui::PopID();
        y += 46.f;
    }

    // footer
    const mac::SysInfo sys = mac::ProbeSystem();
    float fy = origin.y + size.y - 74.f;
    dl->AddLine(ImVec2(origin.x + 18.f, fy - 14.f), ImVec2(origin.x + kSide - 18.f, fy - 14.f),
                C_EDGE);
    Txt(ImVec2(origin.x + 20.f, fy), sys.os.empty() ? "macOS" : sys.os.c_str(), 12.5f, C_LO);
    Txt(ImVec2(origin.x + 20.f, fy + 20.f), "Mac port 0.1", 12.f, C_DIM);
    Txt(ImVec2(origin.x + 20.f, fy + 38.f), "Apple silicon + Intel", 12.f, C_DIM);
}

// ---------------------------------------------------------------------------
// dashboard
// ---------------------------------------------------------------------------
static void StatCard(ImVec2 p, float w, float h, const char* label, const std::string& value,
                     const std::string& sub, float frac, ImU32 col) {
    ImDrawList* dl = ImGui::GetWindowDrawList();
    dl->AddRectFilled(p, ImVec2(p.x + w, p.y + h), C_CARD, 14.f);
    dl->AddRect(p, ImVec2(p.x + w, p.y + h), C_EDGE, 14.f);
    Txt(ImVec2(p.x + 16.f, p.y + 14.f), label, 10.5f, C_DIM);
    Txt(ImVec2(p.x + 16.f, p.y + 34.f), Fit(value, 19.f, w - 32.f), 19.f, C_HI);
    if (!sub.empty())
        Txt(ImVec2(p.x + 16.f, p.y + 62.f), Fit(sub, 12.f, w - 32.f, g_small), 12.f, C_LO, g_small);
    if (frac >= 0.f) Bar(ImVec2(p.x + 16.f, p.y + h - 20.f), w - 32.f, frac, col);
}

static void PageDashboard() {
    PageHeader("Dashboard", "What this Mac is and how hard it is working.");

    const mac::SysInfo sys = mac::ProbeSystem();
    const float w = ImGui::GetContentRegionAvail().x;
    const float gap = 14.f;
    const float cw = (w - gap * 3.f) / 4.f;
    ImVec2 p = ImGui::GetCursorScreenPos();

    int onCount = 0;
    for (const auto& kv : g.on) if (kv.second) onCount++;

    StatCard(p, cw, 104.f, "CHIP", sys.chip.empty() ? "Unknown" : sys.chip,
             sys.cores ? (std::to_string(sys.cores) + " cores") : "", -1.f, C_ACC);
    char memLine[64];
    snprintf(memLine, sizeof(memLine), "%.1f of %d GB", sys.memUsed * sys.memTotalGb,
             sys.memTotalGb);
    StatCard(ImVec2(p.x + cw + gap, p.y), cw, 104.f, "MEMORY", memLine, "in use right now",
             (float)sys.memUsed, C_ACC);
    char diskLine[64];
    snprintf(diskLine, sizeof(diskLine), "%llu GB free", sys.diskFreeGb);
    StatCard(ImVec2(p.x + (cw + gap) * 2.f, p.y), cw, 104.f, "DISK", diskLine,
             std::to_string(sys.diskTotalGb) + " GB total", (float)sys.diskUsed, C_OK);
    if (sys.battery >= 0) {
        char bat[32];
        snprintf(bat, sizeof(bat), "%d%%", sys.battery);
        StatCard(ImVec2(p.x + (cw + gap) * 3.f, p.y), cw, 104.f, "BATTERY", bat,
                 sys.charging ? "on power" : "on battery", sys.battery / 100.f,
                 sys.battery < 20 ? C_WARN : C_OK);
    } else {
        StatCard(ImVec2(p.x + (cw + gap) * 3.f, p.y), cw, 104.f, "BATTERY", "Mains",
                 "no battery on this Mac", -1.f, C_OK);
    }

    // claim the stat row, then lay the two cards out under it
    ImGui::Dummy(ImVec2(w, 126.f));
    ImGui::SetCursorScreenPos(ImVec2(p.x, p.y + 122.f));
    const float bigW = w * 0.56f;
    const float rightW = w - bigW - gap;

    // quick actions
    CardBegin("quick", bigW, 214.f);
    {
        ImVec2 q = ImGui::GetCursorScreenPos();
        Txt(q, "Quick actions", 15.f, C_HI);
        Txt(ImVec2(q.x, q.y + 24.f), "The same tools as the Tools page, one click away.", 12.f, C_LO, g_small);
        ImGui::SetCursorScreenPos(ImVec2(q.x, q.y + 52.f));

        struct QA { const char* label; const char* tool; bool primary; };
        static const QA qa[] = {
            {"Flush DNS", "mac.dns", true},
            {"Free memory", "mac.purge", false},
            {"Restart Dock", "mac.dock", false},
            {"Renew DHCP", "mac.dhcp", false},
        };
        const float bw = (bigW - 36.f - 10.f) / 2.f;
        for (int i = 0; i < 4; i++) {
            if (i == 2) ImGui::SetCursorScreenPos(ImVec2(q.x, q.y + 52.f + 44.f));
            if (i == 1 || i == 3) ImGui::SameLine(0.f, 10.f);
            const std::string key = qa[i].tool;
            char label[64];
            snprintf(label, sizeof(label), "%s##qa%d", qa[i].label, i);
            if (Btn(label, ImVec2(bw, 36.f), qa[i].primary, Busy())) {
                const std::string name = qa[i].label;
                StartJob(name, [key, name]() {
                    const mac::ToolOut o = mac::RunTool(key);
                    JobResult(o.ok, name + ": " + o.text);
                });
            }
        }
        ImGui::SetCursorScreenPos(ImVec2(q.x, q.y + 144.f));
        if (Busy())
            Txt(ImVec2(q.x, q.y + 148.f), Fit(JobLabel() + " - working", 12.f, bigW - 60.f, g_small),
                12.f, C_ACC, g_small);
        else
            Txt(ImVec2(q.x, q.y + 148.f),
                "Tools marked admin ask for your password when they run.", 12.f, C_DIM, g_small);
    }
    CardEnd();

    ImGui::SetCursorScreenPos(ImVec2(p.x + bigW + gap, p.y + 122.f));
    CardBegin("glance", rightW, 214.f);
    {
        ImVec2 q = ImGui::GetCursorScreenPos();
        Txt(q, "This Mac", 15.f, C_HI);
        const float lh = 27.f;
        float y = q.y + 30.f;
        auto line = [&](const char* k, const std::string& v) {
            Txt(ImVec2(q.x, y), k, 12.f, C_DIM, g_small);
            Txt(ImVec2(q.x + 92.f, y), Fit(v, 12.5f, rightW - 120.f, g_small), 12.5f, C_HI, g_small);
            y += lh;
        };
        line("System", sys.os.empty() ? "macOS" : sys.os);
        line("Model", sys.model.empty() ? "unknown" : sys.model);
        line("Tweaks on", std::to_string(onCount) + " of " +
                             std::to_string((int)mac::TweakCatalog().size()));
        line("Tools", std::to_string((int)mac::ToolCatalog().size()) + " available");
        line("Stored in", "~/Library/Application Support");
        Txt(ImVec2(q.x, q.y + 168.f), "Nothing leaves this Mac.", 12.f, C_DIM, g_small);
    }
    CardEnd();
}

// ---------------------------------------------------------------------------
// tweaks
// ---------------------------------------------------------------------------
static void PageTweaks() {
    PageHeader("Tweaks",
               "Each row is one preference. It applies at once and can be switched back.");

    // category chips
    std::vector<std::string> cats{"All"};
    for (const mac::Tweak& t : mac::TweakCatalog())
        if (std::find(cats.begin(), cats.end(), t.cat) == cats.end()) cats.push_back(t.cat);

    const ImVec2 p = ImGui::GetCursorScreenPos();
    float x = p.x;
    for (const std::string& c : cats)
        if (Chip(c.c_str(), g.cat == c, &x, p.y)) g.cat = c;
    ImGui::Dummy(ImVec2(1.f, 8.f));

    ImGui::Dummy(ImVec2(1.f, 6.f));
    const float availH = ImGui::GetContentRegionAvail().y - 6.f;
    ImGui::PushStyleColor(ImGuiCol_ChildBg, ImGui::ColorConvertU32ToFloat4(C_CARD));
    ImGui::PushStyleColor(ImGuiCol_Border, ImGui::ColorConvertU32ToFloat4(C_EDGE));
    ImGui::PushStyleVar(ImGuiStyleVar_ChildRounding, 14.f);
    ImGui::PushStyleVar(ImGuiStyleVar_ChildBorderSize, 1.f);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(6.f, 6.f));
    ImGui::BeginChild("tweaks", ImVec2(0.f, availH), ImGuiChildFlags_Borders);

    ImDrawList* dl = ImGui::GetWindowDrawList();
    const float rowW = ImGui::GetContentRegionAvail().x - 8.f;
    int shown = 0;
    for (const mac::Tweak& t : mac::TweakCatalog()) {
        if (g.cat != "All" && g.cat != t.cat) continue;
        shown++;
        const ImVec2 rp = ImGui::GetCursorScreenPos();
        ImGui::PushID(t.key.c_str());
        ImGui::InvisibleButton("row", ImVec2(rowW, 66.f));
        const bool hov = ImGui::IsItemHovered();
        const bool clicked = ImGui::IsItemClicked();

        if (hov) dl->AddRectFilled(rp, ImVec2(rp.x + rowW, rp.y + 60.f), C_HOV, 10.f);
        const bool on = g.on.count(t.key) ? g.on[t.key] : false;
        Txt(ImVec2(rp.x + 16.f, rp.y + 12.f), t.title, 14.5f, C_HI);
        std::string sub = t.desc;
        if (!t.restart.empty()) {
            // "killall Finder" -> "restarts Finder"
            std::string app = t.restart;
            const size_t sp = app.find(' ');
            if (sp != std::string::npos) app = app.substr(sp + 1);
            sub += "   -   restarts " + app;
        }
        Txt(ImVec2(rp.x + 16.f, rp.y + 34.f), Fit(sub, 12.f, rowW - 110.f, g_small), 12.f, C_LO,
            g_small);
        Switch(ImVec2(rp.x + rowW - 34.f, rp.y + 30.f), on);
        ImGui::PopID();

        if (clicked) {
            const bool next = !on;
            if (mac::ApplyTweak(t, next)) {
                g.on[t.key] = next;
                SetToast(std::string(t.title) + (next ? " on" : " off"), true);
            } else {
                SetToast(std::string("macOS refused that change: ") + t.title, false);
            }
        }
        ImGui::SetCursorScreenPos(ImVec2(rp.x, rp.y + 62.f));
    }
    if (!shown)
        Txt(ImGui::GetCursorScreenPos(), "No tweaks in this category.", 13.f, C_DIM);
    ImGui::EndChild();
    ImGui::PopStyleVar(3);
    ImGui::PopStyleColor(2);
}

// ---------------------------------------------------------------------------
// tools
// ---------------------------------------------------------------------------
static void PageTools() {
    PageHeader("Tools", "One-shot commands. Most only report; the admin ones change the system.");

    const float availH = ImGui::GetContentRegionAvail().y - 6.f;
    ImGui::BeginChild("tools", ImVec2(0.f, availH), ImGuiChildFlags_None);
    const float w = ImGui::GetContentRegionAvail().x;
    std::string lastCat;
    bool first = true;
    const std::vector<mac::Tool>& tools = mac::ToolCatalog();
    for (size_t ti = 0; ti < tools.size(); ti++) {
        const mac::Tool& t = tools[ti];
        if (t.cat != lastCat) {
            lastCat = t.cat;
            if (!first) Spacer(16.f);
            first = false;
            const ImVec2 cp = ImGui::GetCursorScreenPos();
            Txt(cp, t.cat, 12.f, C_DIM);
            ImGui::Dummy(ImVec2(1.f, 22.f));
            ImGui::PushStyleColor(ImGuiCol_ChildBg, ImGui::ColorConvertU32ToFloat4(C_CARD));
            ImGui::PushStyleColor(ImGuiCol_Border, ImGui::ColorConvertU32ToFloat4(C_EDGE));
            ImGui::PushStyleVar(ImGuiStyleVar_ChildRounding, 14.f);
            ImGui::PushStyleVar(ImGuiStyleVar_ChildBorderSize, 1.f);
            ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(18.f, 8.f));
            ImGui::BeginChild(("cat_" + t.cat).c_str(), ImVec2(w, 0.f),
                              ImGuiChildFlags_Borders | ImGuiChildFlags_AutoResizeY);
        }
        const float rw = ImGui::GetContentRegionAvail().x;
        const ImVec2 rp = ImGui::GetCursorScreenPos();
        ImGui::PushID(t.key.c_str());
        ImGui::InvisibleButton("toolrow", ImVec2(rw, 62.f));
        Txt(ImVec2(rp.x, rp.y + 12.f), t.title, 14.5f, C_HI);
        Txt(ImVec2(rp.x, rp.y + 34.f), Fit(t.desc, 12.f, rw - 130.f, g_small), 12.f, C_LO, g_small);
        if (t.admin) Pill(ImVec2(rp.x + TW(t.title, 14.5f) + 12.f, rp.y + 12.f), "ADMIN", C_WARN,
                          IM_COL32(48, 38, 22, 255));
        ImGui::SetCursorScreenPos(ImVec2(rp.x + rw - 92.f, rp.y + 15.f));
        if (Btn("Run", ImVec2(76.f, 32.f), false, Busy())) {
            const std::string key = t.key, title = t.title;
            StartJob(title, [key, title]() {
                const mac::ToolOut o = mac::RunTool(key);
                JobResult(o.ok, title + ":\n" + o.text);
            });
        }
        ImGui::PopID();
        if (ti + 1 < tools.size() && tools[ti + 1].cat == t.cat)
            ImGui::GetWindowDrawList()->AddLine(ImVec2(rp.x, rp.y + 60.f),
                                                ImVec2(rp.x + rw, rp.y + 60.f),
                                                IM_COL32(26, 35, 47, 255));
        ImGui::SetCursorScreenPos(ImVec2(rp.x, rp.y + 62.f));
        // the last tool of a category closes its card
        if (ti + 1 == tools.size() || tools[ti + 1].cat != t.cat) {
            ImGui::EndChild();
            ImGui::PopStyleVar(3);
            ImGui::PopStyleColor(2);
        }
    }
    ImGui::EndChild();
}

// ---------------------------------------------------------------------------
// cleaner
// ---------------------------------------------------------------------------
static void PageCleaner() {
    PageHeader("Disk cleaner",
               "Files that only take up space. Pick the groups, then delete them in one go.");

    if (!g.scanned && !Busy()) {
        StartJob("Scanning caches", []() { JobGroups(mac::ScanCleaner()); });
    }

    unsigned long long total = 0, picked = 0;
    int pickedGroups = 0;
    for (const mac::CleanGroup& c : g.groups) {
        total += c.bytes;
        if (g.pick.count(c.key)) {
            picked += c.bytes;
            pickedGroups++;
        }
    }

    const float w = ImGui::GetContentRegionAvail().x;
    const ImVec2 p = ImGui::GetCursorScreenPos();

    // reserve the summary band, then fill it absolutely
    ImGui::Dummy(ImVec2(w, 132.f));
    ImGui::SetCursorScreenPos(p);

    // summary card
    ImDrawList* dl = ImGui::GetWindowDrawList();
    dl->AddRectFilled(p, ImVec2(p.x + w, p.y + 112.f), C_CARD, 14.f);
    dl->AddRect(p, ImVec2(p.x + w, p.y + 112.f), C_EDGE, 14.f);
    Txt(ImVec2(p.x + 20.f, p.y + 20.f), ICON_TRASH, 30.f, C_ACC, g_icons);
    Txt(ImVec2(p.x + 72.f, p.y + 16.f), "Selected to delete", 11.f, C_DIM);
    Txt(ImVec2(p.x + 72.f, p.y + 34.f), mac::SizeText(picked), 27.f, C_HI);
    Txt(ImVec2(p.x + 72.f, p.y + 72.f),
        std::to_string(pickedGroups) + " of " + std::to_string((int)g.groups.size()) +
            " groups selected - " + mac::SizeText(total) + " found",
        12.f, C_LO, g_small);

    ImGui::SetCursorScreenPos(ImVec2(p.x + w - 330.f, p.y + 38.f));
    if (Btn("Rescan", ImVec2(92.f, 38.f), false, Busy())) {
        StartJob("Scanning caches", []() { JobGroups(mac::ScanCleaner()); });
    }
    ImGui::SameLine(0.f, 10.f);
    if (Btn(picked ? "Delete selected" : "Nothing selected", ImVec2(210.f, 38.f), true,
            Busy() || pickedGroups == 0)) {
        std::vector<std::string> keys(g.pick.begin(), g.pick.end());
        StartJob("Cleaning", [keys]() {
            const mac::CleanOut r = mac::CleanRun(keys);
            char msg[160];
            snprintf(msg, sizeof(msg), "Freed %s across %d groups%s", mac::SizeText(r.freed).c_str(),
                     r.groups, r.files ? (" and " + std::to_string(r.files) + " files").c_str() : "");
            JobResult(true, msg);
            JobGroups(mac::ScanCleaner());
        });
    }

    ImGui::SetCursorScreenPos(ImVec2(p.x, p.y + 132.f));
    const float availH = ImGui::GetContentRegionAvail().y - 6.f;
    CardBegin("cleanlist", w, availH);
    {
        if (g.groups.empty() && Busy()) {
            Txt(ImGui::GetCursorScreenPos(), "Measuring folders - this can take a few seconds.",
                13.f, C_LO);
        }
        for (const mac::CleanGroup& c : g.groups) {
            const ImVec2 rp = ImGui::GetCursorScreenPos();
            const float rw = ImGui::GetContentRegionAvail().x;
            ImGui::PushID(c.key.c_str());
            ImGui::InvisibleButton("group", ImVec2(rw, 72.f));
            const bool hov = ImGui::IsItemHovered();
            const bool clicked = ImGui::IsItemClicked();
            if (hov)
                ImGui::GetWindowDrawList()->AddRectFilled(rp, ImVec2(rp.x + rw, rp.y + 66.f), C_HOV,
                                                          10.f);
            const bool on = g.pick.count(c.key) > 0;
            Switch(ImVec2(rp.x + 32.f, rp.y + 30.f), on);
            Txt(ImVec2(rp.x + 68.f, rp.y + 14.f), c.title, 14.5f, C_HI);
            Txt(ImVec2(rp.x + 68.f, rp.y + 37.f), Fit(c.desc, 12.f, rw - 300.f, g_small), 12.f,
                C_LO, g_small);
            const std::string size = mac::SizeText(c.bytes);
            Txt(ImVec2(rp.x + rw - TW(size, 14.f) - 18.f, rp.y + 14.f), size, 14.f, C_HI);
            const std::string files = std::to_string(c.files) + " files";
            Txt(ImVec2(rp.x + rw - TW(files, 12.f, g_small) - 18.f, rp.y + 38.f), files, 12.f,
                C_DIM, g_small);
            ImGui::PopID();
            if (clicked) {
                if (on) g.pick.erase(c.key);
                else g.pick.insert(c.key);
            }
            ImGui::SetCursorScreenPos(ImVec2(rp.x, rp.y + 70.f));
        }
    }
    CardEnd();
}

// ---------------------------------------------------------------------------
// about
// ---------------------------------------------------------------------------
static void PageAbout() {
    PageHeader("About", "A macOS build of 3hz Tweaks, written against the Mac's own tools.");

    const float w = ImGui::GetContentRegionAvail().x;
    const float leftW = w * 0.58f;
    ImVec2 p = ImGui::GetCursorScreenPos();

    CardBegin("aboutmain", leftW, 320.f);
    {
        ImVec2 q = ImGui::GetCursorScreenPos();
        float y = q.y;
        auto section = [&](const char* head, const char* body) {
            Txt(ImVec2(q.x, y), head, 14.5f, C_HI);
            y += 22.f;
            y += Para(ImVec2(q.x, y), body, 12.5f, C_LO, leftW - 52.f, 19.f);
            y += 16.f;
        };
        section("What this is",
                "The Windows build drives the registry, services, WMI and netsh. Macs have none "
                "of those, so this port keeps the same shape and puts macOS tools behind it: "
                "defaults for preferences, pmset for power, sysctl, vm_stat and df for the "
                "numbers, and the filesystem for cleanup.");
        section("How tweaks are written",
                "Every toggle writes one preference with defaults write, then restarts whichever "
                "app caches it - Dock, Finder or SystemUIServer. Switching it back writes the "
                "previous value, so nothing is one-way.");
        section("What needs a password",
                "Only the tools marked admin: flushing DNS, renewing a lease, purging memory, "
                "rebuilding the Spotlight index. They go through the normal macOS authorisation "
                "dialog, and the app itself never runs as root.");
        ImGui::SetCursorScreenPos(ImVec2(q.x, y));
    }
    CardEnd();

    ImGui::SetCursorScreenPos(ImVec2(p.x + leftW + 14.f, p.y));
    CardBegin("aboutsafe", w - leftW - 14.f, 320.f);
    {
        ImVec2 q = ImGui::GetCursorScreenPos();
        Txt(q, "Before you delete", 14.5f, C_HI);
        Txt(ImVec2(q.x, q.y + 24.f),
            Fit("The cleaner removes files. Nothing is copied to the bin first.", 12.f,
                w - leftW - 60.f, g_small),
            12.f, C_WARN, g_small);
        float y = q.y + 50.f;
        y += Para(ImVec2(q.x, y),
                  "Caches and logs come back on their own. Derived data rebuilds on the next "
                  "Xcode build, and package caches refill on the next install - the first build "
                  "afterwards will be slower.",
                  12.5f, C_LO, w - leftW - 60.f, 19.f);
        y += 14.f;
        y += Para(ImVec2(q.x, y),
                  "Trash is deleted for good. Temporary items are only cleared if they are more "
                  "than a day old, because macOS keeps live scratch files in that folder.",
                  12.5f, C_LO, w - leftW - 60.f, 19.f);
        y += 18.f;
        Txt(ImVec2(q.x, y), "Version 0.1 (Mac)", 12.f, C_DIM, g_small);
        Txt(ImVec2(q.x, y + 18.f), "Built with Dear ImGui + GLFW", 12.f, C_DIM, g_small);
        ImGui::SetCursorScreenPos(ImVec2(q.x, y + 40.f));
    }
    CardEnd();
}

// ---------------------------------------------------------------------------
// frame
// ---------------------------------------------------------------------------
void UI_SetFonts(ImFont* body, ImFont* small, ImFont* icons) {
    g_body = body;
    g_small = small;
    g_icons = icons;
}

void UI_Init() {
    for (const mac::Tweak& t : mac::TweakCatalog()) g.on[t.key] = mac::ReadTweak(t);
}

void UI_PreferredSize(float* w, float* h) {
    *w = 1200.f;
    *h = 800.f;
}

void UI_Frame() {
    PumpJob();
    if (!g_body) g_body = ImGui::GetIO().Fonts->Fonts[0];
    if (!g_small) g_small = g_body;
    if (!g_icons) g_icons = g_body;

    const ImGuiViewport* vp = ImGui::GetMainViewport();
    ImGui::SetNextWindowPos(vp->WorkPos);
    ImGui::SetNextWindowSize(vp->WorkSize);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0.f, 0.f));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 0.f);
    ImGui::Begin("3hz", nullptr,
                 ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize |
                     ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoCollapse |
                     ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoBringToFrontOnFocus |
                     ImGuiWindowFlags_NoScrollWithMouse);

    const ImVec2 origin = ImGui::GetWindowPos();
    const ImVec2 size = ImGui::GetWindowSize();
    ImGui::GetWindowDrawList()->AddRectFilled(origin, ImVec2(origin.x + size.x, origin.y + size.y),
                                              C_BG);
    Sidebar(origin, size);

    ImGui::SetCursorScreenPos(ImVec2(origin.x + kSide, origin.y));
    // ImGui only honours WindowPadding on a child that has the borders flag, so
    // the border is asked for and then made invisible - that is what gives the
    // page its 30 px gutter.
    ImGui::PushStyleColor(ImGuiCol_ChildBg, ImGui::ColorConvertU32ToFloat4(C_BG));
    ImGui::PushStyleColor(ImGuiCol_Border, ImVec4(0.f, 0.f, 0.f, 0.f));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(kPad, 24.f));
    ImGui::PushStyleVar(ImGuiStyleVar_ChildBorderSize, 0.f);
    ImGui::BeginChild("content", ImVec2(size.x - kSide, size.y),
                      ImGuiChildFlags_Borders | ImGuiChildFlags_AlwaysUseWindowPadding,
                      ImGuiWindowFlags_None);
    switch (g.page) {
        case Page_Dash: PageDashboard(); break;
        case Page_Tweaks: PageTweaks(); break;
        case Page_Tools: PageTools(); break;
        case Page_Cleaner: PageCleaner(); break;
        case Page_About: PageAbout(); break;
    }
    ImGui::EndChild();
    ImGui::PopStyleVar(2);
    ImGui::PopStyleColor(2);

    // toast, bottom right, over everything
    if (!g.toast.empty() && ImGui::GetTime() - g.toastAt < 7.0) {
        ImDrawList* dl = ImGui::GetWindowDrawList();
        const float maxW = size.x - kSide - kPad * 2.f;
        std::string msg = g.toast;
        std::string line;
        std::vector<std::string> lines;
        for (size_t i = 0; i <= msg.size(); i++) {
            const size_t nl = msg.find('\n', i);
            const std::string part = msg.substr(i, nl == std::string::npos ? std::string::npos : nl - i);
            if (TW(part, 12.5f, g_small) <= maxW - 40.f) {
                lines.push_back(part);
            } else {
                lines.push_back(Fit(part, 12.5f, maxW - 40.f, g_small));
            }
            if (nl == std::string::npos) break;
            i = nl;
        }
        lines.resize(std::min<size_t>(lines.size(), 4));
        float h = 20.f + (float)lines.size() * 18.f;
        const ImVec2 b(size.x - kPad - 4.f, size.y - 18.f);
        const float bw = maxW * 0.62f;
        const ImVec2 a(b.x - bw, b.y - h);
        dl->AddRectFilled(a, b, IM_COL32(20, 28, 39, 250), 12.f);
        dl->AddRect(a, b, g.toastOk ? C_OK : IM_COL32(200, 96, 110, 255), 12.f);
        dl->AddCircleFilled(ImVec2(a.x + 16.f, a.y + h * 0.5f), 4.f, g.toastOk ? C_OK : C_WARN, 16);
        for (size_t i = 0; i < lines.size(); i++)
            dl->AddText(g_small, 12.5f, ImVec2(a.x + 28.f, a.y + 10.f + i * 18.f), C_HI,
                        lines[i].c_str());
    }

    ImGui::End();
    ImGui::PopStyleVar(2);
}
