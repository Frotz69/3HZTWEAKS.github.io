#pragma once
// 3hz Tweaks for macOS - interface.
#include "imgui.h"

// Fonts live in main.cpp because the atlas is built there. Passing them in keeps
// this file free of file paths and platform code.
void UI_SetFonts(ImFont* body, ImFont* small, ImFont* icons);
void UI_Init();
void UI_Frame();
// Height the app asks the window to be, so main.cpp can centre it.
void UI_PreferredSize(float* w, float* h);
