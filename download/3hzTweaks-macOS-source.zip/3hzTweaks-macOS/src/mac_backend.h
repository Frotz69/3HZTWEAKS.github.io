#pragma once
// 3hz Tweaks for macOS - backend.
//
// The Windows app talks to the registry, WMI, services and netsh. macOS has no
// equivalent, so this is not a port of backend.cpp: it is the same shape with
// Mac tools behind it - `defaults` for preferences, `pmset` for power, sysctl /
// vm_stat / df for the numbers, and the filesystem for cleanup. Every tweak is
// reversible: the current value is read, and the old one is written back.
#include <map>
#include <string>
#include <vector>

namespace mac {

// ---- paths -----------------------------------------------------------------
std::string HomeDir();
std::string AppSupportDir();     // ~/Library/Application Support/3hz Tweaks
std::string ConfigPath();

std::map<std::string, std::string> LoadConfig();
void SaveConfig(const std::map<std::string, std::string>& cfg);

// Runs a command line through /bin/sh -c. True on exit status 0; `out` receives
// stdout. stderr is dropped - every caller here wants the answer, not the noise.
bool Run(const std::string& cmd, std::string* out = nullptr);
// Same, through AppleScript's "do shell script ... with administrator
// privileges", which raises the normal authorisation dialog. Only for the tools
// marked admin.
bool RunAdmin(const std::string& cmd, std::string* out = nullptr);

// ---- system facts ----------------------------------------------------------
// Measured at most a few seconds apart: the dashboard asks every frame.
struct SysInfo {
    std::string chip;        // "Apple M2 Pro" / "Intel(R) Core(TM) i7-9750H"
    std::string os;          // "macOS 14.5"
    std::string model;       // "MacBookPro18,3"
    int cores = 0;
    int memTotalGb = 0;
    double memUsed = 0.0;    // 0..1
    double diskUsed = 0.0;   // 0..1
    unsigned long long diskFreeGb = 0, diskTotalGb = 0;
    int battery = -1;        // -1 when this Mac has no battery
    bool charging = false;
};
SysInfo ProbeSystem(bool force = false);

// ---- tweaks ----------------------------------------------------------------
// A tweak is a key in a preference domain, a value that means "on", and the two
// commands that set it. `readCmd` prints the current value; the tweak is on
// when that output equals `onValue`. `restart` re-launches whatever caches the
// preference (Dock, Finder, SystemUIServer) so the change shows at once.
struct Tweak {
    std::string key, title, desc, cat;
    std::string readCmd, onCmd, offCmd, onValue, restart;
};

const std::vector<Tweak>& TweakCatalog();
bool ReadTweak(const Tweak& t);
bool ApplyTweak(const Tweak& t, bool on);   // true when the write succeeded

// ---- one-shot tools --------------------------------------------------------
struct Tool {
    std::string key, title, desc, cat;
    bool admin = false;      // needs the authorisation dialog to do all of it
};
const std::vector<Tool>& ToolCatalog();
struct ToolOut { bool ok = false; std::string text; };
ToolOut RunTool(const std::string& key);     // call on a worker thread

// ---- cleaner ---------------------------------------------------------------
struct CleanGroup {
    std::string key, title, desc;
    unsigned long long bytes = 0;
    int files = 0;
};
std::vector<CleanGroup> ScanCleaner();
struct CleanOut { unsigned long long freed = 0; int files = 0, groups = 0; };
CleanOut CleanRun(const std::vector<std::string>& keys);
// Bytes currently held by one group - used for the freed figure and by tools.
unsigned long long GroupBytesFor(const std::string& key);

std::string SizeText(unsigned long long bytes);

} // namespace mac
