// 3hz Tweaks for macOS - entry point.
//
// The Windows build hosts Dear ImGui on Win32 + Direct3D 11. Here it runs on
// GLFW + OpenGL 3.2 core, which is what a Mac gives you without Metal. The
// interface and theme code is the same shape as the other build; only the
// platform glue below differs.
#include "imgui.h"
#include "imgui_impl_glfw.h"
#include "imgui_impl_opengl3.h"
#include "ui_mac.h"

#include <GLFW/glfw3.h>

#include <cstdio>
#include <cstring>
#include <string>
#include <unistd.h>

#ifdef __APPLE__
#include <mach-o/dyld.h>
#endif

static void GlfwError(int code, const char* desc) {
    fprintf(stderr, "glfw error %d: %s\n", code, desc);
}

// Assets ship inside the .app (Contents/Resources/assets). When the binary is
// run straight out of the build tree there is no bundle, so the copied folder
// next to the executable and finally the source tree are tried in turn.
static std::string AssetPath(const char* name) {
    std::string dir;
#ifdef __APPLE__
    char exe[4096];
    uint32_t size = sizeof(exe);
    if (_NSGetExecutablePath(exe, &size) == 0) {
        dir = exe;
        const size_t cut = dir.find_last_of('/');
        if (cut != std::string::npos) dir = dir.substr(0, cut);
    }
#endif
    const char* relative[] = {"/assets/", "/../Resources/assets/", "/Resources/assets/"};
    if (!dir.empty()) {
        for (const char* rel : relative) {
            const std::string p = dir + rel + name;
            if (access(p.c_str(), R_OK) == 0) return p;
        }
    }
#ifdef MACOS_PORT_ASSET_DIR
    {
        const std::string p = std::string(MACOS_PORT_ASSET_DIR) + "/" + name;
        if (access(p.c_str(), R_OK) == 0) return p;
    }
#endif
    return "";
}

static void ApplyTheme() {
    ImGuiStyle& st = ImGui::GetStyle();
    ImGui::StyleColorsDark();
    st.WindowRounding = 0.f;
    st.FrameRounding = 8.f;
    st.ChildRounding = 12.f;
    st.PopupRounding = 8.f;
    st.ScrollbarRounding = 8.f;
    st.GrabRounding = 8.f;
    st.FramePadding = ImVec2(10.f, 6.f);
    st.ItemSpacing = ImVec2(8.f, 8.f);
    st.ScrollbarSize = 8.f;
    // Same geometry budget as the Windows build: smoother arcs for a few more
    // triangles on the cards and the switches.
    st.CircleTessellationMaxError = 0.10f;
    st.AntiAliasedLines = true;
    st.AntiAliasedFill = true;

    st.Colors[ImGuiCol_WindowBg] = ImVec4(0.035f, 0.047f, 0.067f, 1.f);
    st.Colors[ImGuiCol_ChildBg] = ImVec4(0.039f, 0.055f, 0.078f, 1.f);
    st.Colors[ImGuiCol_PopupBg] = ImVec4(0.055f, 0.071f, 0.094f, 0.98f);
    st.Colors[ImGuiCol_Text] = ImVec4(0.933f, 0.953f, 0.976f, 1.f);
    st.Colors[ImGuiCol_TextDisabled] = ImVec4(0.482f, 0.533f, 0.604f, 1.f);
    st.Colors[ImGuiCol_Button] = ImVec4(0.047f, 0.075f, 0.11f, 1.f);
    st.Colors[ImGuiCol_ButtonHovered] = ImVec4(0.078f, 0.125f, 0.188f, 1.f);
    st.Colors[ImGuiCol_ButtonActive] = ImVec4(0.357f, 0.659f, 0.941f, 1.f);
    st.Colors[ImGuiCol_Border] = ImVec4(0.125f, 0.169f, 0.227f, 1.f);
    st.Colors[ImGuiCol_Separator] = ImVec4(0.125f, 0.169f, 0.227f, 1.f);
    st.Colors[ImGuiCol_ScrollbarBg] = ImVec4(0.f, 0.f, 0.f, 0.f);
    st.Colors[ImGuiCol_ScrollbarGrab] = ImVec4(0.20f, 0.25f, 0.31f, 1.f);
    st.Colors[ImGuiCol_ScrollbarGrabHovered] = ImVec4(0.28f, 0.34f, 0.41f, 1.f);
    st.Colors[ImGuiCol_NavHighlight] = ImVec4(0.357f, 0.659f, 0.941f, 1.f);
}

static void LoadFonts(ImFont** body, ImFont** icons) {
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr;
    // One font at the base size; 1.92 rasterises any size asked for at runtime,
    // including the headings the interface draws at 26 px.
    ImFontConfig cfg;
    cfg.PixelSnapH = true;
    const std::string inter = AssetPath("Inter.ttf");
    ImFont* f = inter.empty() ? nullptr : io.Fonts->AddFontFromFileTTF(inter.c_str(), 18.f, &cfg);
    if (!f) f = io.Fonts->AddFontDefault();

    const std::string fa = AssetPath("fa-solid-900.ttf");
    static const ImWchar faRanges[] = {0xf000, 0xf8ff, 0};
    if (!fa.empty()) {
        ImFontConfig merge;
        merge.MergeMode = true;
        merge.PixelSnapH = true;
        merge.GlyphMinAdvanceX = 18.f;
        io.Fonts->AddFontFromFileTTF(fa.c_str(), 17.f, &merge, faRanges);

        ImFontConfig iconCfg;
        iconCfg.PixelSnapH = true;
        *icons = io.Fonts->AddFontFromFileTTF(fa.c_str(), 17.f, &iconCfg, faRanges);
    }
    *body = f;
    if (!*icons) *icons = f;
}

int main(int, char**) {
    glfwSetErrorCallback(GlfwError);
    if (!glfwInit()) return 1;

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 2);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GLFW_TRUE);
    glfwWindowHint(GLFW_COCOA_RETINA_FRAMEBUFFER, GLFW_TRUE);

    float wantW = 1200.f, wantH = 800.f;
    UI_PreferredSize(&wantW, &wantH);
    int workX = 0, workY = 0, workW = 1440, workH = 900;
    if (GLFWmonitor* mon = glfwGetPrimaryMonitor()) {
        int mx = 0, my = 0, mw = 0, mh = 0;
        glfwGetMonitorWorkarea(mon, &mx, &my, &mw, &mh);
        if (mw > 0 && mh > 0) {
            workX = mx; workY = my; workW = mw; workH = mh;
        }
    }
    const int winW = (int)(wantW < (float)workW ? wantW : (float)workW);
    const int winH = (int)(wantH < (float)workH ? wantH : (float)workH);

    GLFWwindow* win = glfwCreateWindow(winW, winH, "3hz Tweaks", nullptr, nullptr);
    if (!win) {
        glfwTerminate();
        return 1;
    }
    glfwSetWindowPos(win, workX + (workW - winW) / 2, workY + (workH - winH) / 2);
    glfwSetWindowSizeLimits(win, 980, 640, GLFW_DONT_CARE, GLFW_DONT_CARE);
    glfwMakeContextCurrent(win);
    glfwSwapInterval(1);

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;

    // Retina: the framebuffer is 2x the window on every Mac built since 2012,
    // so fonts are rasterised at 2x and laid out at point sizes.
    float scaleX = 1.f, scaleY = 1.f;
    glfwGetWindowContentScale(win, &scaleX, &scaleY);
    ImGuiStyle& st = ImGui::GetStyle();
    ImFont* body = nullptr;
    ImFont* icons = nullptr;
    LoadFonts(&body, &icons);
    ApplyTheme();
    st.FontSizeBase = 18.f;
    st.FontScaleDpi = scaleX > 0.f ? scaleX : 1.f;

    UI_SetFonts(body, body, icons);
    ImGui_ImplGlfw_InitForOpenGL(win, true);
    ImGui_ImplOpenGL3_Init("#version 150");
    UI_Init();

    while (!glfwWindowShouldClose(win)) {
        glfwPollEvents();

        // Cmd+Q, since a plain binary has no application menu to provide it.
        if (io.KeySuper && !io.WantTextInput && ImGui::IsKeyPressed(ImGuiKey_Q, false))
            glfwSetWindowShouldClose(win, GLFW_TRUE);

        ImGui_ImplOpenGL3_NewFrame();
        ImGui_ImplGlfw_NewFrame();
        ImGui::NewFrame();
        UI_Frame();
        ImGui::Render();

        int fbW = 0, fbH = 0;
        glfwGetFramebufferSize(win, &fbW, &fbH);
        glViewport(0, 0, fbW, fbH);
        glClearColor(0.035f, 0.047f, 0.067f, 1.f);
        glClear(GL_COLOR_BUFFER_BIT);
        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
        glfwSwapBuffers(win);
    }

    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplGlfw_Shutdown();
    ImGui::DestroyContext();
    glfwDestroyWindow(win);
    glfwTerminate();
    return 0;
}
